/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package XapSepCoSo_9;

/**
 *
 * @author nguyenquanghuy
 */
public class NhiemVu {
    private String maSv, maDt;

    public NhiemVu(String maSv, String maDt) {
        this.maSv = maSv;
        this.maDt = maDt;
    }

    public String getMaSv() {
        return maSv;
    }

    public void setMaSv(String maSv) {
        this.maSv = maSv;
    }

    public String getMaDt() {
        return maDt;
    }

    public void setMaDt(String maDt) {
        this.maDt = maDt;
    }
    
    
}
